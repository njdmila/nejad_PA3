package problem2;

public class SavingsAccount {
    private static double annualInterestRate;
    private double savingsBalance;

    public SavingsAccount(double savingsBalance) {

        this.savingsBalance = savingsBalance;
    }

    double getSavingsBalance() {

        return this.savingsBalance;
    }

    public void calculateMonthlyInterest() {
        double monthlyInterest;
        monthlyInterest = (double) (this.savingsBalance * annualInterestRate / 12.00);
        this.savingsBalance += monthlyInterest;
    }


    public static void modifyInterestRate(double newRate) {

        annualInterestRate = newRate;
    }
}
