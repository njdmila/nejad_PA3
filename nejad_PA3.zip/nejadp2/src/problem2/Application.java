package problem2;

public class Application {

    public static void main(String[] args) {

        SavingsAccount saver1 = new SavingsAccount(2000);
        SavingsAccount saver2 = new SavingsAccount(3000);

        SavingsAccount.modifyInterestRate (0.04);

        //Server 1 After 12mo 4%
        System.out.print("Saver 1 Balance After 12 months: ");
        for(int i=0; i < 12; i++) {

            saver1.calculateMonthlyInterest();
        }
        System.out.printf("$%.2f", saver1.getSavingsBalance());

        //Server 2 After 12mo 4%
        System.out.print("\nSaver 2 Balance After 12 months: ");
        for(int i=0; i < 12; i++) {

            saver2.calculateMonthlyInterest();
        }
        System.out.printf("$%.2f", saver2.getSavingsBalance());

        //Change interest rate to 5%
        SavingsAccount.modifyInterestRate(0.05);

        //Server 1 After 12mo 5%
        System.out.print("\n\nServer 1 Balance 5% interest: ");

        saver1.calculateMonthlyInterest();
        System.out.printf("$%.2f", saver1.getSavingsBalance());

        //Server 2 After 12mo 5%
        System.out.print("\nServer 2 Balance 5% interest: ");
        saver2.calculateMonthlyInterest();
        System.out.printf("$%.2f", saver2.getSavingsBalance());
    }
}