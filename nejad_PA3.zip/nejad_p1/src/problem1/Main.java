package problem1;
/*
Name: Mila Nejad
Date: 10/19/2019
COP 3330 Assignment 3 IntelliJ calculator
 */

import java.security.SecureRandom;
import java.util.Scanner;

public class Main {
    private static int correctAnswers = 0;
    private static int difficulty;
    private static int rand1, rand2, solution;
    private static int operation = 0;

    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        int i = 0;

        //endlessly resets the program so another student can try it
        while (i != 1) {
            while (difficulty > 4 || difficulty < 1) {
                System.out.print("Please enter program difficulty (1-4): ");
                difficulty = scnr.nextInt();
                System.out.print("\n");
            }
            while (operation > 5 || operation < 1) {
                System.out.print("Enter Operation:\n1: Addition\n2: Multiplication\n3: Subtraction\n4: Division\n5: Random Mixture\n");
                operation = scnr.nextInt();
                System.out.print("\n");
            }

            questionPrinter();
        }

    }
    private static void askQuestion() {
        SecureRandom rand = new SecureRandom();

        switch (difficulty) {
            case 1:
                rand1 = rand.nextInt(10);
                rand2 = rand.nextInt(10);
                while (rand2 == 0) {
                    rand2 = rand.nextInt(10);
                }
                break;
            case 2:
                rand1 = rand.nextInt(100);
                rand2 = rand.nextInt(100);
                while (rand2 == 0) {
                    rand2 = rand.nextInt(100);
                }
                break;
            case 3:
                rand1 = rand.nextInt(1000);
                rand2 = rand.nextInt(1000);
                while (rand2 == 0) {
                    rand2 = rand.nextInt(1000);
                }
                break;
            case 4:
                rand1 = rand.nextInt(10000);
                rand2 = rand.nextInt(10000);
                while (rand2 == 0) {
                    rand2 = rand.nextInt(10000);
                }
                break;
        }

        switch (operation) {
            case 1:
                solution = rand1 + rand2;
                System.out.printf("How much is %d plus %d?\n", rand1, rand2);
                break;
            case 2:
                solution = rand1 * rand2;
                System.out.printf("How much is %d times %d?\n", rand1, rand2);
                break;
            case 3:
                solution = rand1 - rand2;
                System.out.printf("How much is %d minus %d?\n", rand1, rand2);
                break;
            case 4:
                solution = rand1 / rand2;
                System.out.printf("How much is %d divided by %d?\n", rand1, rand2);
                break;
            case 5:
                int tempor = rand.nextInt(4);
                switch(tempor) {
                    case 0:
                        solution = rand1 + rand2;
                        System.out.printf("How much is %d plus %d?\n", rand1, rand2);
                        break;
                    case 1:
                        solution = rand1 * rand2;
                        System.out.printf("How much is %d times %d?\n", rand1, rand2);
                        break;
                    case 2:
                        solution = rand1 - rand2;
                        System.out.printf("How much is %d minus %d?\n", rand1, rand2);
                        break;
                    case 3:
                        solution = rand1 / rand2;
                        System.out.printf("How much is %d divided by %d?\n", rand1, rand2);
                        break;
                }
                break;
        }

        checkSolution(getSolution(), solution);

    }
    private static void percentChecker() {

        double percentage = ((double) correctAnswers / 10.00) * 100.00;
        System.out.println("Percent Correct: " + percentage);

        if (percentage >= 75.00) {
            System.out.println("Congratulations, you are ready to go to the next level!");
            System.out.print("\n\nNEXT STUDENT >>>\n");
            difficulty = 0;
            operation = 0;
        } else {
            System.out.println("Please ask your teacher for extra help.");
            System.out.print("\n\nNEXT STUDENT >>>\n");
            difficulty = 0;
            operation = 0;
        }
    }
    private static void questionPrinter() {
        for (int i = 0; i < 10; i++) {
            askQuestion();
        }
        percentChecker();

    }

    private static void checkSolution(int userAnswer, int solution) {
        if (userAnswer == solution) {
            correctAnswer();
        } else {
            incorrectAnswer();
//            checkSolution(getSolution(), solution); this allows the user to Re-enter incorrect answers and guarentees 100%
        }

    }

    private static int getSolution() {
        Scanner scnr = new Scanner(System.in);

        int userAnswer = scnr.nextInt();
        return userAnswer;
    }

    private static void correctAnswer() {
        SecureRandom rando = new SecureRandom();
        correctAnswers++;

        int whatwhat = (rando.nextInt(5) + 1);

        switch (whatwhat) {
            case 1:
                System.out.println("Very Good!");
                break;
            case 2:
                System.out.println("Excellent!");
                break;
            case 3:
                System.out.println("Nice work!");
                break;
            case 4:
                System.out.println("Keep up the good work!");
                break;
            default:
                System.out.println("Very Good!");
                break;
        }
    }

    private static void incorrectAnswer() {
        SecureRandom rando = new SecureRandom();
        int whatwhat = (rando.nextInt(5) + 1);

        switch (whatwhat) {
            case 1:
                System.out.println("No. Please try again.");
                break;
            case 2:
                System.out.println("Wrong. Try once more.");
                break;
            case 3:
                System.out.println("Don’t give up!");
                break;
            case 4:
                System.out.println("No. Keep trying.");
                break;
            default:
                System.out.println("No. Please try again.");
                break;

        }
    }
}
